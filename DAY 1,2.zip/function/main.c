#include<stdio.h>
// function banana 
void sayhello(){
    printf("Hello Hitesh!\n");
}
int main(){
    sayhello();
    sayhello();
    sayhello();
    return 0;
    
}