#include<stdio.h>
int main(){
    int marks = 17;
    if (marks>0){
        printf("positive!\n");
    }else if (marks<0) {
        printf("negative!\n");
    }else{
        printf("Zero!\n");
    }
    return 0;
}