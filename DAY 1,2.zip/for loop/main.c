#include<stdio.h>
int main(){
    int i;
    for (i =1;i<=10;i++){
        printf("count:%d\n",i);
    }
    return 0 ;
}