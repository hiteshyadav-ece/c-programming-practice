#include <stdio.h>
int main(){
    printf (" nam hitesh kam tabhi!\n");
    printf (" i study in gju ,hisar!\n");
    printf ("my goal is to get a high package!\n" );
}