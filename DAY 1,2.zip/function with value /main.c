#include<stdio.h>
int multiply(int a,int b){
    return a*b;
}
int main(){
    int result = multiply(1777,6785);
    printf("multiply = %d\n",result);
    return 0;
}