#include<stdio.h>
int main (){
    int marks = 80;
    if (marks >=60){
        printf("pass\n");
    }else{
        printf("fail\n");
    }
    return 0;
}