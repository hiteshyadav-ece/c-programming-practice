#include<stdio.h>
int add(int a,int b){
    return a+b;
}
int main(){
    int result = add(987,367);
    printf("sum = %d\n",result);
    return 0;
}