#include<stdio.h>
int main(){
    int marks[5] = {85,67,89,90,34};
    int i;
    int total = 0;
    for(i = 0;i<5;i++){
        total=total+marks[i];
        printf ("Subject %d marks: %d\n",i+1,marks[i]);
    }
    printf("Total:%d\n",total);
    printf("Average:%.2f\n",(float)total/5);
    return 0;
}