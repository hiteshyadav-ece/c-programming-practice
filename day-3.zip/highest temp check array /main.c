#include<stdio.h>
int main(){
    int temp[5] = {32,35,38,40,33};
    int max =temp[0];
    int i;
    for(i = 0;i<5;i++){
        if (temp[i]>max){
            max=temp[i];
        }
   } 
    printf("Highest temprature:%d\n",max);
    return 0;
}