#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main(){
    srand (time(0));
    int secret = rand()%500+1;
    int guess;
    int attempts=0;
    printf("Number Guessing Game!\n");
    printf("Guess number between 1 and 500!\n");
    
    while(1){
        printf("Enter your guess!\n");
        scanf("%d",&guess);
        attempts++;
        
        if(guess<secret){
            printf("Too Low! Try higher!\n");
        }else if (guess>secret){
            printf("Too High! Try lower!\n");
        }else{
            printf("CORRECT! You got it in %d attempts!\n",attempts);
            break;
        }
    }
    return 0;
}
